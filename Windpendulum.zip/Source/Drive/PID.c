#include "stm32f10x.h"
#include "stdio.h"
#include "delay.h"
#include "NixieTube.h"
#include "PID.h"


PIDValue PID_p;
PIDValue PID_r;


void PID_p_Set()
{
	PID_p.past=0;
	PID_p.set=10;
	PID_p.real=0;
	PID_p.p=4.0;
	PID_p.i=1;
	PID_p.d=30500000;
	return;
}

void PID_1_Operation()
{
	int temp[3]={0};
	
	
			temp[0]=PID_p.set-PID_p.real;
			//PID_p.flag[1]=0;
			PID_p.val[2]=PID_p.val[1];
			PID_p.val[1]=PID_p.val[0];
			PID_p.val[0]=temp[0];
			temp[0]=PID_p.val[0]-PID_p.val[1];
			temp[2]=PID_p.val[1]*2;
			temp[2]=(PID_p.val[0]+PID_p.val[2])-temp[2];
			
			temp[0]=PID_p.p*temp[0];
			temp[1]=PID_p.i*PID_p.val[0];
			temp[2]=PID_p.d*temp[2];
			PID_p.past=temp[0]+temp[1]+temp[2];	
     
				
	       
			
	
	//PID_p.real+=(int)(PID_p.past*0.1);
}
void PID_r_Set()
{
	PID_r.past=0;
	PID_r.set=10;
	PID_r.real=0;
	PID_r.p=4.0;
	PID_r.i=1;
	PID_r.d=30500000;
	return;
}

void PID_2_Operation()
{
	int temp[3]={0};
	
	
	
	{
			temp[0]=PID_r.set-PID_r.real;
			//PID_r.flag[1]=0;
			PID_r.val[2]=PID_r.val[1];
			PID_r.val[1]=PID_r.val[0];
			PID_r.val[0]=temp[0];
			temp[0]=PID_r.val[0]-PID_r.val[1];
			temp[2]=PID_r.val[1]*2;
			temp[2]=(PID_r.val[0]+PID_r.val[2])-temp[2];
			
			temp[0]=PID_r.p*temp[0];
			temp[1]=PID_r.i*PID_r.val[0];
			temp[2]=PID_r.d*temp[2];
			PID_r.past=temp[0]+temp[1]+temp[2];	
			 
				
			
		}
	//PID_r.real+=(int)(PID_r.past*0.1);
}

