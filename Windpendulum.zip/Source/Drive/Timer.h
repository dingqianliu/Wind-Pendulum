#include "stm32f10x.h"

void RCC_Configuration(void);
void GPIO_Config(void);
void TIM3_Config(void);
void TIM2_Config(void);
