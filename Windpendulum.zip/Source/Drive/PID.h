#include "stm32f10x.h"
typedef struct 
{
	float val[3];//cha
	float flag[3];//zheng fu biao zhi
	float p;
	float i;
	float d;
	float past;
	float set;//she ding zhi
	float real;
}PIDValue;



void PID_1_Set(void);
void PID_2_Set(void);
void PID_1_Operation(void);
void PID_2_Operation(void);
